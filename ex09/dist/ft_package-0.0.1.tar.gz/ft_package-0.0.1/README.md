# ft_package

This is a simple Python package that counts occurrences of an item in a list.
